
const express = require('express');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const songsRoutes = require('./routes/songs');
const playlistsRoutes = require('./routes/playlists');
const playbackRoutes = require('./routes/playback');
const libraryRoutes = require('./routes/library');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());


app.use('/auth', authRoutes);
app.use('/songs', songsRoutes);
app.use('/playlists', playlistsRoutes);
app.use('/playback', playbackRoutes);
app.use('/library', libraryRoutes);


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
